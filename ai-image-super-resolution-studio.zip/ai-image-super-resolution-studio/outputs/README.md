# Outputs

| File | What it is | Provenance |
|---|---|---|
| `figures/report_training_milestones.png` | Loss + PSNR/SSIM at epochs 1/15/30/50 | Re-drawn from **Table 4 of the project report** |
| `figures/report_benchmark_comparison.png` | Bicubic vs SRCNN vs SRResNet vs ESRGAN on Set5/Set14 | Re-drawn from **Table 5 of the project report** |
| `logs/report_reported_metrics.json` | Machine-readable copy of Tables 4 and 5 | Transcribed from the report |
| `logs/train_log.csv` | Per-epoch log | **Created by `train.py`** when you train |
| `figures/training_curves.png` | Full 50-epoch curves | Created by `scripts/plot_training.py` after training |
| `results/<dataset>/` | Bicubic / ESRGAN / GT strips + `metrics.csv` | Created by `evaluate.py` |

After training, regenerate real outputs with the commands in the main README. The report's
figures (Fig. 3-6) are images in the PDF and are not reproduced here.
