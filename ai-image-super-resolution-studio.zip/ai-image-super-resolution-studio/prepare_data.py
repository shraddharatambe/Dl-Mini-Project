"""Extract sliding-window HR patches (optional offline alternative to on-the-fly cropping).

    python prepare_data.py --train_dir data/DIV2K_train_HR --patch_size 256 --stride 128
Writes data/patches_HR/*.png and data/patches_LR/*.png (bicubic x4).
"""
import argparse
import os

import cv2
from tqdm import tqdm

from datasets import list_images


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train_dir", default="data/DIV2K_train_HR")
    ap.add_argument("--out_dir", default="data")
    ap.add_argument("--patch_size", type=int, default=256)
    ap.add_argument("--stride", type=int, default=128)
    ap.add_argument("--scale", type=int, default=4)
    a = ap.parse_args()

    hr_out, lr_out = os.path.join(a.out_dir, "patches_HR"), os.path.join(a.out_dir, "patches_LR")
    os.makedirs(hr_out, exist_ok=True); os.makedirs(lr_out, exist_ok=True)
    n = 0
    for f in tqdm(list_images(a.train_dir)):
        img = cv2.imread(f)
        h, w = img.shape[:2]
        for y in range(0, h - a.patch_size + 1, a.stride):
            for x in range(0, w - a.patch_size + 1, a.stride):
                hr = img[y:y + a.patch_size, x:x + a.patch_size]
                lr = cv2.resize(hr, (a.patch_size // a.scale,) * 2, interpolation=cv2.INTER_CUBIC)
                name = f"{os.path.splitext(os.path.basename(f))[0]}_{y}_{x}.png"
                cv2.imwrite(os.path.join(hr_out, name), hr); cv2.imwrite(os.path.join(lr_out, name), lr)
                n += 1
    print(f"Saved {n} patch pairs to {a.out_dir}")


if __name__ == "__main__":
    main()
