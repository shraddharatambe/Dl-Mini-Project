"""Two-phase ESRGAN training.

Phase 1 (pretrain_epochs): generator trained with L1 only.
Phase 2 (remaining epochs): L_total = L_vgg + lambda * L_G^Ra + eta * L1, with RaGAN discriminator.

Usage:
    python train.py --config configs/esrgan_div2k.yaml --batch_size 16 --epochs 50 --lr 1e-4
"""
import argparse
import csv
import os
import time

import numpy as np
import torch
import torch.nn as nn
import yaml
from torch.utils.data import DataLoader
from tqdm import tqdm

from datasets import SRTrainDataset, SRValDataset
from models import RRDBNet, RelativisticDiscriminator, VGGFeatureExtractor
from utils.losses import d_loss_ra, g_loss_ra
from utils.metrics import psnr, ssim
from utils.image_ops import to_image


def parse():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/esrgan_div2k.yaml")
    ap.add_argument("--batch_size", type=int)
    ap.add_argument("--epochs", type=int)
    ap.add_argument("--lr", type=float)
    ap.add_argument("--resume", type=str, default=None)
    return ap.parse_args()


@torch.no_grad()
def validate(netG, loader, device):
    netG.eval()
    ps, ss = [], []
    for lr, hr in loader:
        sr = netG(lr.to(device))
        sr_img, hr_img = to_image(sr), to_image(hr.to(device))
        ps.append(psnr(sr_img, hr_img))
        ss.append(ssim(sr_img, hr_img))
    netG.train()
    return float(np.mean(ps)), float(np.mean(ss))


def main():
    args = parse()
    cfg = yaml.safe_load(open(args.config))
    t, d, m = cfg["train"], cfg["data"], cfg["model"]
    if args.batch_size: t["batch_size"] = args.batch_size
    if args.epochs: t["epochs"] = args.epochs
    if args.lr: t["lr"] = args.lr

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_amp = bool(t["amp"]) and device.type == "cuda"
    print(f"Device: {device} | AMP: {use_amp}")

    train_ds = SRTrainDataset(d["train_dir"], d["hr_patch"], d["scale"], d["crops_per_image"])
    val_ds = SRValDataset(d["valid_dir"], d["scale"])
    train_dl = DataLoader(train_ds, t["batch_size"], shuffle=True, num_workers=d["num_workers"],
                          pin_memory=True, drop_last=True)
    val_dl = DataLoader(val_ds, 1, shuffle=False)

    netG = RRDBNet(nf=m["nf"], gc=m["gc"], num_rrdb=m["num_rrdb"], beta=m["beta"]).to(device)
    netD = RelativisticDiscriminator().to(device)
    vgg = VGGFeatureExtractor().to(device)
    print(f"Generator params: {sum(p.numel() for p in netG.parameters()):,} | "
          f"Discriminator params: {sum(p.numel() for p in netD.parameters()):,}")

    betas = (t["beta1"], t["beta2"])
    opt_G = torch.optim.Adam(netG.parameters(), lr=t["lr"], betas=betas)
    opt_D = torch.optim.Adam(netD.parameters(), lr=t["lr"], betas=betas)
    scaler_G = torch.amp.GradScaler("cuda", enabled=use_amp)
    scaler_D = torch.amp.GradScaler("cuda", enabled=use_amp)
    l1 = nn.L1Loss()

    start_epoch = 1
    if args.resume:
        ck = torch.load(args.resume, map_location=device)
        netG.load_state_dict(ck["netG"]); netD.load_state_dict(ck["netD"])
        opt_G.load_state_dict(ck["opt_G"]); opt_D.load_state_dict(ck["opt_D"])
        start_epoch = ck["epoch"] + 1

    os.makedirs(t["ckpt_dir"], exist_ok=True)
    os.makedirs(os.path.dirname(t["log_csv"]), exist_ok=True)
    new_log = not os.path.exists(t["log_csv"]) or start_epoch == 1
    logf = open(t["log_csv"], "w" if new_log else "a", newline="")
    log = csv.writer(logf)
    if new_log:
        log.writerow(["epoch", "phase", "l1", "vgg", "adv_g", "loss_d", "val_psnr", "val_ssim", "sec"])

    for epoch in range(start_epoch, t["epochs"] + 1):
        gan_phase = epoch > t["pretrain_epochs"]
        meters = {k: [] for k in ("l1", "vgg", "adv", "d")}
        t0 = time.time()
        for lr_img, hr_img in tqdm(train_dl, desc=f"Epoch {epoch}/{t['epochs']}", leave=False):
            lr_img, hr_img = lr_img.to(device, non_blocking=True), hr_img.to(device, non_blocking=True)

            # ---------------- Generator forward ----------------
            with torch.autocast(device.type, enabled=use_amp):
                sr_img = netG(lr_img)
                loss_pixel = l1(sr_img, hr_img)

            if not gan_phase:                       # Phase 1: L1 only
                opt_G.zero_grad(set_to_none=True)
                scaler_G.scale(loss_pixel).backward()
                scaler_G.step(opt_G); scaler_G.update()
                meters["l1"].append(loss_pixel.item())
                continue

            # ---------------- Discriminator step ----------------
            opt_D.zero_grad(set_to_none=True)
            with torch.autocast(device.type, enabled=use_amp):
                pred_real = netD(hr_img)
                pred_fake = netD(sr_img.detach())
                loss_D = d_loss_ra(pred_real, pred_fake)
            scaler_D.scale(loss_D).backward()
            scaler_D.step(opt_D); scaler_D.update()

            # ---------------- Generator step ----------------
            opt_G.zero_grad(set_to_none=True)
            with torch.autocast(device.type, enabled=use_amp):
                pred_fake_g = netD(sr_img)
                with torch.no_grad():
                    pred_real_g = netD(hr_img)
                loss_adv = g_loss_ra(pred_real_g, pred_fake_g)
                loss_vgg = l1(vgg(sr_img), vgg(hr_img).detach())
                loss_G = loss_vgg + t["lambda_adv"] * loss_adv + t["eta_l1"] * loss_pixel
            scaler_G.scale(loss_G).backward()
            scaler_G.step(opt_G); scaler_G.update()

            meters["l1"].append(loss_pixel.item()); meters["vgg"].append(loss_vgg.item())
            meters["adv"].append(loss_adv.item()); meters["d"].append(loss_D.item())

        vp, vs = validate(netG, val_dl, device) if epoch % t["val_every"] == 0 else (float("nan"),) * 2
        mean = lambda k: float(np.mean(meters[k])) if meters[k] else float("nan")
        sec = time.time() - t0
        log.writerow([epoch, "gan" if gan_phase else "pretrain", mean("l1"), mean("vgg"),
                      mean("adv"), mean("d"), vp, vs, f"{sec:.1f}"]); logf.flush()
        print(f"[{epoch:02d}] L1={mean('l1'):.4f} VGG={mean('vgg'):.4f} Gadv={mean('adv'):.4f} "
              f"D={mean('d'):.4f} | PSNR={vp:.2f} SSIM={vs:.4f} | {sec:.0f}s")

        torch.save({"epoch": epoch, "netG": netG.state_dict(), "netD": netD.state_dict(),
                    "opt_G": opt_G.state_dict(), "opt_D": opt_D.state_dict()},
                   os.path.join(t["ckpt_dir"], f"esrgan_epoch{epoch}.pth"))
    logf.close()


if __name__ == "__main__":
    main()
