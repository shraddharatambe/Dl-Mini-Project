import cv2
import numpy as np
import torch


def to_tensor(img_uint8: np.ndarray, device) -> torch.Tensor:
    t = torch.from_numpy(np.ascontiguousarray(img_uint8.transpose(2, 0, 1))).float() / 255.0
    return t.unsqueeze(0).to(device)


def to_image(t: torch.Tensor) -> np.ndarray:
    a = t.squeeze(0).clamp(0, 1).cpu().numpy().transpose(1, 2, 0)
    return (a * 255.0).round().astype(np.uint8)


def bicubic_down(hr: np.ndarray, scale: int = 4) -> np.ndarray:
    h, w = hr.shape[:2]
    return cv2.resize(hr, (w // scale, h // scale), interpolation=cv2.INTER_CUBIC)


def bicubic_up(lr: np.ndarray, scale: int = 4) -> np.ndarray:
    h, w = lr.shape[:2]
    return cv2.resize(lr, (w * scale, h * scale), interpolation=cv2.INTER_CUBIC)


@torch.no_grad()
def tiled_inference(net, lr: torch.Tensor, scale: int = 4, tile: int = 128, overlap: int = 16):
    """Run `net` on overlapping tiles to avoid GPU OOM on large images.

    Overlapping borders are discarded when stitching to hide seams.
    tile=0 disables tiling.
    """
    _, c, h, w = lr.shape
    if tile <= 0 or (h <= tile and w <= tile):
        return net(lr)
    out = torch.zeros(1, c, h * scale, w * scale, device=lr.device)
    stride = tile - 2 * overlap
    for y in range(0, h, stride):
        for x in range(0, w, stride):
            y0, x0 = max(y - overlap, 0), max(x - overlap, 0)
            y1, x1 = min(y + stride + overlap, h), min(x + stride + overlap, w)
            sr = net(lr[:, :, y0:y1, x0:x1])
            ty0, tx0 = (y - y0) * scale, (x - x0) * scale
            ty1, tx1 = ty0 + min(stride, h - y) * scale, tx0 + min(stride, w - x) * scale
            out[:, :, y * scale:(y + min(stride, h - y)) * scale,
                      x * scale:(x + min(stride, w - x)) * scale] = sr[:, :, ty0:ty1, tx0:tx1]
    return out


def load_generator(ckpt_path: str, device, **kw):
    from models import RRDBNet
    net = RRDBNet(**kw).to(device)
    ck = torch.load(ckpt_path, map_location=device)
    state = ck.get("netG", ck.get("params_ema", ck)) if isinstance(ck, dict) else ck
    net.load_state_dict(state, strict=True)
    return net.eval()
