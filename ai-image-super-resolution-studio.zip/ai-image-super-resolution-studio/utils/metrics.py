import numpy as np
from skimage.metrics import structural_similarity


def rgb_to_y(img):
    """uint8/float RGB (0-255) -> Y channel (BT.601), float64 in [16,235]."""
    img = img.astype(np.float64)
    return 16.0 + (65.481 * img[..., 0] + 128.553 * img[..., 1] + 24.966 * img[..., 2]) / 255.0


def psnr(a, b, shave=4, y_channel=True):
    a, b = _prep(a, b, shave, y_channel)
    mse = np.mean((a - b) ** 2)
    return float("inf") if mse == 0 else 20 * np.log10(255.0 / np.sqrt(mse))


def ssim(a, b, shave=4, y_channel=True):
    a, b = _prep(a, b, shave, y_channel)
    return float(structural_similarity(a, b, data_range=255.0))


def _prep(a, b, shave, y_channel):
    if y_channel:
        a, b = rgb_to_y(a), rgb_to_y(b)
    else:
        a, b = a.astype(np.float64), b.astype(np.float64)
    if shave > 0:
        a, b = a[shave:-shave, shave:-shave], b[shave:-shave, shave:-shave]
    return a, b
