import torch
import torch.nn as nn

bce = nn.BCEWithLogitsLoss()


def d_loss_ra(pred_real, pred_fake):
    """Relativistic average discriminator loss."""
    real = bce(pred_real - pred_fake.mean(), torch.ones_like(pred_real))
    fake = bce(pred_fake - pred_real.mean(), torch.zeros_like(pred_fake))
    return (real + fake) / 2


def g_loss_ra(pred_real, pred_fake):
    """Relativistic average generator (adversarial) loss: labels are swapped."""
    real = bce(pred_real - pred_fake.mean(), torch.zeros_like(pred_real))
    fake = bce(pred_fake - pred_real.mean(), torch.ones_like(pred_fake))
    return (real + fake) / 2
