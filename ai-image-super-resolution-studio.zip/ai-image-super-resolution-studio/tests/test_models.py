import torch
from models import RRDBNet, RelativisticDiscriminator
from utils.losses import d_loss_ra, g_loss_ra
from utils.image_ops import tiled_inference


def test_generator_shape():
    net = RRDBNet(num_rrdb=2).eval()
    with torch.no_grad():
        assert net(torch.rand(1, 3, 32, 32)).shape == (1, 3, 128, 128)


def test_discriminator_any_size():
    d = RelativisticDiscriminator()
    assert d(torch.rand(2, 3, 128, 128)).shape == (2, 1)
    assert d(torch.rand(2, 3, 256, 256)).shape == (2, 1)


def test_losses_finite():
    r, f = torch.randn(4, 1), torch.randn(4, 1)
    assert torch.isfinite(d_loss_ra(r, f)) and torch.isfinite(g_loss_ra(r, f))


def test_tiling_matches_full():
    net = RRDBNet(num_rrdb=1).eval()
    x = torch.rand(1, 3, 70, 90)
    full = net(x)
    tiled = tiled_inference(net, x, tile=48, overlap=16)
    assert tiled.shape == full.shape
    # receptive field > overlap, so tiny border differences are expected
    assert (full - tiled).abs().mean() < 0.05
