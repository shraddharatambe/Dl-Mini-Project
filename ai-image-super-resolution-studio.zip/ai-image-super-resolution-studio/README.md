# AI Image Super-Resolution Studio

4× single-image super-resolution with **ESRGAN** (RRDB-Net generator, Relativistic average discriminator,
VGG-19 perceptual loss) plus an interactive **Gradio** web app.

Mini Project · B.E. Artificial Intelligence & Data Science · A. C. Patil College of Engineering, Kharghar (University of Mumbai, AY 2026-27)
**Team:** Sameer Dhole · Shravani Patil · Shruti Wardhe · Clint Thomas  **Guide:** Prof. Suryakala A. V.

## Highlights
- **Generator:** 16 RRDB blocks (3 dense blocks × 5 convs each), **no BatchNorm**, residual scaling β = 0.2, two PixelShuffle ×2 stages → 4×
- **Discriminator:** VGG-style, 7 convs (64→512 ch), LeakyReLU, Spectral Norm; relativistic average loss (RaGAN)
- **Loss:** `L = L_vgg(conv5_4, pre-activation) + 0.005·L_adv + 0.01·L1`
- **Training:** 10 epochs L1 warm-up + 40 epochs GAN, Adam (lr 1e-4, β=(0.9, 0.999)), batch 16, AMP FP16
- **Data:** DIV2K (800 train / 100 valid), 256×256 HR crops ↔ 64×64 bicubic LR; test on Set5 / Set14
- **App:** drag-and-drop upload, optional denoise, tiled inference for large images, PNG download

## Repository layout
```
├── models/            rrdb.py · discriminator.py · vgg_loss.py
├── utils/             losses.py · metrics.py (PSNR/SSIM, Y-channel) · image_ops.py (tiling, loaders)
├── configs/           esrgan_div2k.yaml
├── scripts/           download_div2k.py · plot_training.py · make_report_figures.py
├── tests/             test_models.py
├── datasets.py  prepare_data.py  train.py  evaluate.py  infer.py  app_gradio.py
└── outputs/           figures/ · logs/ (see outputs/README.md for provenance)
```

## Quick start
```bash
git clone https://github.com/<your-username>/ai-image-super-resolution-studio.git
cd ai-image-super-resolution-studio
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt                          # for CUDA 12.1: pip install torch==2.1.2 torchvision==0.16.2 --index-url https://download.pytorch.org/whl/cu121

# 1. Data
python scripts/download_div2k.py                         # DIV2K train/valid (≈ 4 GB); put Set5/Set14 HR images in data/Set5, data/Set14
python prepare_data.py --train_dir data/DIV2K_train_HR --patch_size 256 --stride 128   # optional offline patches

# 2. Train (50 epochs; checkpoints in checkpoints/, log in outputs/logs/train_log.csv)
python train.py --config configs/esrgan_div2k.yaml --batch_size 16 --epochs 50 --lr 1e-4
python scripts/plot_training.py

# 3. Evaluate (PSNR / SSIM on Y channel, latency, optional --lpips)
python evaluate.py --ckpt checkpoints/esrgan_epoch50.pth --dataset data/Set5  --save_dir outputs/results/Set5
python evaluate.py --ckpt checkpoints/esrgan_epoch50.pth --dataset data/Set14 --save_dir outputs/results/Set14

# 4. Use it
python infer.py --ckpt checkpoints/esrgan_epoch50.pth --input photo.png --output photo_4x.png
python app_gradio.py --ckpt checkpoints/esrgan_epoch50.pth --port 7860   # open http://localhost:7860
```
Run tests: `pytest -q`. Google Colab: choose a T4 runtime, `!pip install -r requirements.txt`, then run the same commands.

## Results reported in the project report
| Method | Set5 PSNR / SSIM | Set14 PSNR / SSIM | GPU latency |
|---|---|---|---|
| Bicubic | 28.42 / 0.8104 | 26.00 / 0.7027 | < 1 ms |
| SRCNN | 30.48 / 0.8628 | 27.50 / 0.7513 | 12.4 ms |
| SRResNet | 32.05 / 0.8910 | 28.49 / 0.7820 | 28.6 ms |
| **ESRGAN Studio** | **32.84 / 0.9142** | **29.12 / 0.8124** | 48.2 ms |

![benchmarks](outputs/figures/report_benchmark_comparison.png)
![training](outputs/figures/report_training_milestones.png)

> These numbers and plots are copied from the project report. Re-run `train.py` / `evaluate.py`
> on your hardware to reproduce or replace them; your results will differ somewhat.

## Implementation notes
- The generator in this repo uses **PixelShuffle** upsampling and 16 RRDBs as described in the report; the exact parameter count
  printed by `train.py` will differ from the 16.7 M in Table 3 (16 RRDBs with nf=64, gc=32 is roughly 12 M parameters).
- The discriminator uses **Spectral Normalization** (no BatchNorm) and adaptive pooling so it works for any crop size.
  The report's code listing shows BatchNorm and fewer layers; the text (Sec. 5.4) describes the Spectral-Norm, 7-conv version, which is what is implemented here.
- PSNR/SSIM are computed on the Y (luminance) channel with a 4-pixel border shave.
- Tiled inference (`--tile`, default 128 LR px, 16 px overlap) trades a small border difference for much lower VRAM use.

## Limitations
Hallucinated texture on heavily compressed/noisy inputs, distorted fine text and signage, and slow CPU inference (~1.8 s for 1080p). See report §9.

## References
Wang et al. ESRGAN (ECCV-W 2018) · Ledig et al. SRGAN (CVPR 2017) · Dong et al. SRCNN (TPAMI 2016) · Johnson et al. Perceptual Losses (ECCV 2016) · Agustsson & Timofte, DIV2K / NTIRE 2017 · Paszke et al. PyTorch (NeurIPS 2019)

License: MIT
