import glob
import os
import random

import cv2
import numpy as np
import torch
from torch.utils.data import Dataset

EXTS = ("*.png", "*.jpg", "*.jpeg", "*.bmp")


def list_images(folder):
    files = []
    for e in EXTS:
        files += glob.glob(os.path.join(folder, e))
    return sorted(files)


def read_rgb(path):
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


def _to_tensor(img):
    return torch.from_numpy(np.ascontiguousarray(img.transpose(2, 0, 1))).float() / 255.0


class SRTrainDataset(Dataset):
    """Random HR crops (256x256) + on-the-fly bicubic LR (64x64).
    Augmentation: random 90-degree rotation + horizontal flip (p=0.5)."""

    def __init__(self, folder, hr_patch=256, scale=4, crops_per_image=40):
        self.files = list_images(folder)
        if not self.files:
            raise FileNotFoundError(f"No images in {folder}. Run scripts/download_div2k.py first.")
        self.hr_patch, self.scale, self.cpi = hr_patch, scale, crops_per_image
        self.cache = {}

    def __len__(self):
        return len(self.files) * self.cpi

    def __getitem__(self, idx):
        path = self.files[idx // self.cpi]
        if path not in self.cache:
            self.cache[path] = read_rgb(path)
        img = self.cache[path]
        h, w = img.shape[:2]
        p = self.hr_patch
        y, x = random.randint(0, h - p), random.randint(0, w - p)
        hr = img[y:y + p, x:x + p]
        if random.random() < 0.5:
            hr = hr[:, ::-1]
        hr = np.rot90(hr, random.randint(0, 3))
        hr = np.ascontiguousarray(hr)
        lr = cv2.resize(hr, (p // self.scale, p // self.scale), interpolation=cv2.INTER_CUBIC)
        return _to_tensor(lr), _to_tensor(hr)


class SRValDataset(Dataset):
    """Centre crop (<=512) of validation images, LR via bicubic 4x down."""

    def __init__(self, folder, scale=4, max_size=512):
        self.files = list_images(folder)
        self.scale, self.max_size = scale, max_size

    def __len__(self):
        return len(self.files)

    def __getitem__(self, i):
        img = read_rgb(self.files[i])
        h, w = img.shape[:2]
        s = self.scale
        ch, cw = min(h, self.max_size) // s * s, min(w, self.max_size) // s * s
        y, x = (h - ch) // 2, (w - cw) // 2
        hr = img[y:y + ch, x:x + cw]
        lr = cv2.resize(hr, (cw // s, ch // s), interpolation=cv2.INTER_CUBIC)
        return _to_tensor(lr), _to_tensor(hr)
