"""Gradio web studio.   python app_gradio.py --ckpt checkpoints/esrgan_epoch50.pth --port 7860"""
import argparse
import os
import tempfile
import time

import cv2
import gradio as gr
import torch

from utils.image_ops import load_generator, tiled_inference, to_image, to_tensor

ap = argparse.ArgumentParser()
ap.add_argument("--ckpt", required=True)
ap.add_argument("--port", type=int, default=7860)
ap.add_argument("--share", action="store_true")
args = ap.parse_args()

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
netG = load_generator(args.ckpt, device)
DEVICE_NAME = torch.cuda.get_device_name(0) if device.type == "cuda" else "CPU"


def super_resolve(input_img, denoise_strength=0.15, tile=128):
    if input_img is None:
        raise gr.Error("Please upload an image first.")
    img = input_img
    if denoise_strength > 0:   # optional pre-denoise to limit amplification of JPEG/sensor noise
        h = float(denoise_strength) * 20.0
        img = cv2.fastNlMeansDenoisingColored(img, None, h, h, 7, 21)
    t0 = time.time()
    with torch.no_grad():
        sr = to_image(tiled_inference(netG, to_tensor(img, device), tile=int(tile)))
    if device.type == "cuda": torch.cuda.synchronize()
    ms = (time.time() - t0) * 1000
    path = os.path.join(tempfile.mkdtemp(), "super_resolved_4x.png")
    cv2.imwrite(path, cv2.cvtColor(sr, cv2.COLOR_RGB2BGR))
    info = (f"Input {img.shape[1]}x{img.shape[0]} -> Output {sr.shape[1]}x{sr.shape[0]} (4x) | "
            f"Inference {ms:.1f} ms on {DEVICE_NAME}")
    return sr, info, path


with gr.Blocks(title="AI Super-Resolution Studio") as demo:
    gr.Markdown("# AI Image Super-Resolution Studio (4x Upscaler)\nESRGAN · RRDB-Net · Relativistic GAN")
    with gr.Row():
        in_img = gr.Image(label="Upload Low-Res Image", type="numpy")
        out_img = gr.Image(label="Super-Resolved Output (4x HD)", type="numpy")
    with gr.Row():
        denoise = gr.Slider(0, 1, value=0.15, step=0.05, label="Denoise strength")
        tile = gr.Slider(0, 512, value=128, step=32, label="Tile size (0 = off, lower = less VRAM)")
    info = gr.Textbox(label="Info", interactive=False)
    dl = gr.File(label="Download High-Res PNG")
    gr.Button("Enhance Image (4x)", variant="primary").click(
        super_resolve, [in_img, denoise, tile], [out_img, info, dl])

if __name__ == "__main__":
    demo.launch(server_port=args.port, share=args.share)
