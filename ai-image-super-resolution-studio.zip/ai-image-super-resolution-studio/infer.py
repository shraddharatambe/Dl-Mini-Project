"""CLI inference:  python infer.py --ckpt checkpoints/esrgan_epoch50.pth --input in.png --output out.png"""
import argparse

import cv2
import torch

from datasets import read_rgb
from utils.image_ops import load_generator, tiled_inference, to_image, to_tensor


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", default="sr_output.png")
    ap.add_argument("--tile", type=int, default=128, help="LR tile size; 0 disables tiling")
    a = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    net = load_generator(a.ckpt, device)
    sr = to_image(tiled_inference(net, to_tensor(read_rgb(a.input), device), tile=a.tile))
    cv2.imwrite(a.output, cv2.cvtColor(sr, cv2.COLOR_RGB2BGR))
    print("Saved", a.output, sr.shape)


if __name__ == "__main__":
    main()
