"""Benchmark Bicubic vs ESRGAN on Set5 / Set14 (PSNR, SSIM on Y channel, latency, optional LPIPS).

    python evaluate.py --ckpt checkpoints/esrgan_epoch50.pth --dataset data/Set5 --save_dir outputs/results/Set5
"""
import argparse
import csv
import os
import time

import cv2
import numpy as np
import torch

from datasets import list_images, read_rgb
from utils.image_ops import bicubic_down, bicubic_up, load_generator, to_image, to_tensor
from utils.metrics import psnr, ssim


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--scale", type=int, default=4)
    ap.add_argument("--save_dir", default=None)
    ap.add_argument("--lpips", action="store_true")
    a = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    net = load_generator(a.ckpt, device)
    lp = None
    if a.lpips:
        import lpips
        lp = lpips.LPIPS(net="alex").to(device)

    rows = []
    for f in list_images(a.dataset):
        hr = read_rgb(f)
        h, w = (hr.shape[0] // a.scale) * a.scale, (hr.shape[1] // a.scale) * a.scale
        hr = hr[:h, :w]
        lr = bicubic_down(hr, a.scale)
        bic = bicubic_up(lr, a.scale)

        x = to_tensor(lr, device)
        if device.type == "cuda": torch.cuda.synchronize()
        t0 = time.time()
        with torch.no_grad():
            sr = to_image(net(x))
        if device.type == "cuda": torch.cuda.synchronize()
        ms = (time.time() - t0) * 1000

        row = dict(image=os.path.basename(f),
                   bicubic_psnr=psnr(bic, hr), bicubic_ssim=ssim(bic, hr),
                   esrgan_psnr=psnr(sr, hr), esrgan_ssim=ssim(sr, hr), latency_ms=ms)
        if lp is not None:
            t_ = lambda im: torch.from_numpy(im.transpose(2, 0, 1)).float().div(127.5).sub(1).unsqueeze(0).to(device)
            row["esrgan_lpips"] = float(lp(t_(sr), t_(hr)))
        rows.append(row)
        print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in row.items()})

        if a.save_dir:
            os.makedirs(a.save_dir, exist_ok=True)
            stem = os.path.splitext(os.path.basename(f))[0]
            strip = np.concatenate([bic, sr, hr], axis=1)
            cv2.imwrite(os.path.join(a.save_dir, f"{stem}_bicubic_esrgan_gt.png"),
                        cv2.cvtColor(strip, cv2.COLOR_RGB2BGR))

    mean = {k: float(np.mean([r[k] for r in rows])) for k in rows[0] if k != "image"}
    print("\nMEAN:", {k: round(v, 4) for k, v in mean.items()})
    if a.save_dir:
        with open(os.path.join(a.save_dir, "metrics.csv"), "w", newline="") as fh:
            wr = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); wr.writeheader()
            wr.writerows(rows); wr.writerow({"image": "MEAN", **mean})


if __name__ == "__main__":
    main()
