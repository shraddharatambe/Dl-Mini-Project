"""Download DIV2K HR train/valid sets (official ETH Zurich mirror) and unzip into data/."""
import os
import urllib.request
import zipfile

URLS = {
    "DIV2K_train_HR": "http://data.vision.ee.ethz.ch/cvl/DIV2K/DIV2K_train_HR.zip",
    "DIV2K_valid_HR": "http://data.vision.ee.ethz.ch/cvl/DIV2K/DIV2K_valid_HR.zip",
}

for name, url in URLS.items():
    zpath = f"data/{name}.zip"
    if not os.path.exists(zpath):
        print("Downloading", url)
        urllib.request.urlretrieve(url, zpath)
    with zipfile.ZipFile(zpath) as z:
        z.extractall("data/")
    # the zip extracts to data/<name>/*.png already
    print("Extracted", name)
print("Set5 / Set14: place the HR .png files in data/Set5 and data/Set14 "
      "(e.g. from the BasicSR / SRCNN benchmark packs).")
