"""Re-draw figures from the numbers published in the project report (Tables 4 and 5).
These are NOT new experimental results - they visualise the report's recorded values."""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

OUT = "outputs/figures"
os.makedirs(OUT, exist_ok=True)

# ---- Table 4: milestones (report) ----
t4 = dict(epoch=[1, 15, 30, 50], l1=[.2481, .0814, .0452, .0381], vgg=[1.4280, .5921, .3842, .3210],
          adv=[.0812, .0645, .0482, .0389], d=[.7812, .6941, .6890, .6931],
          psnr=[24.82, 29.45, 31.90, 32.84], ssim=[.684, .842, .895, .914])
# ---- Table 5: benchmarks (report) ----
t5 = {"Bicubic": (28.42, .8104, 26.00, .7027, 1), "SRCNN": (30.48, .8628, 27.50, .7513, 12.4),
      "SRResNet": (32.05, .8910, 28.49, .7820, 28.6), "ESRGAN (Ours)": (32.84, .9142, 29.12, .8124, 48.2)}
json.dump({"table4_training_milestones": t4,
           "table5_benchmarks": {k: dict(zip(["set5_psnr", "set5_ssim", "set14_psnr", "set14_ssim", "latency_ms"], v))
                                 for k, v in t5.items()},
           "source": "Values transcribed from AI_Image_Super_Resolution_Report.pdf"},
          open("outputs/logs/report_reported_metrics.json", "w"), indent=2)

# Fig A: training milestones
fig, ax = plt.subplots(1, 2, figsize=(13, 4.5))
ax[0].plot(t4["epoch"], t4["l1"], "o-", label="Pixel L1")
ax[0].plot(t4["epoch"], t4["vgg"], "o-", label="VGG perceptual")
ax[0].plot(t4["epoch"], t4["d"], "o--", label="Relativistic D loss")
ax[0].axhline(np.log(2), color="gray", ls=":", label="ln 2 equilibrium")
ax[0].set(title="Training losses at milestones (report Table 4)", xlabel="Epoch", ylabel="Loss"); ax[0].legend(); ax[0].grid(alpha=.3)
ax[1].plot(t4["epoch"], t4["psnr"], "go-"); ax[1].set(xlabel="Epoch", ylabel="Val PSNR (dB)")
a2 = ax[1].twinx(); a2.plot(t4["epoch"], t4["ssim"], "bs-."); a2.set_ylabel("Val SSIM")
ax[1].set_title("Validation PSNR / SSIM (report Table 4)"); ax[1].grid(alpha=.3)
plt.tight_layout(); plt.savefig(f"{OUT}/report_training_milestones.png", dpi=150); plt.close()

# Fig B: benchmark bars
names = list(t5); x = np.arange(len(names)); w = .38
fig, ax = plt.subplots(1, 2, figsize=(13, 4.5))
ax[0].bar(x - w/2, [t5[n][0] for n in names], w, label="Set5"); ax[0].bar(x + w/2, [t5[n][2] for n in names], w, label="Set14")
ax[0].set_xticks(x, names); ax[0].set(ylabel="PSNR (dB)", title="PSNR (report Table 5)"); ax[0].set_ylim(24, 34); ax[0].legend()
ax[1].bar(x - w/2, [t5[n][1] for n in names], w, label="Set5"); ax[1].bar(x + w/2, [t5[n][3] for n in names], w, label="Set14")
ax[1].set_xticks(x, names); ax[1].set(ylabel="SSIM", title="SSIM (report Table 5)"); ax[1].set_ylim(.65, .95); ax[1].legend()
plt.tight_layout(); plt.savefig(f"{OUT}/report_benchmark_comparison.png", dpi=150); plt.close()
print("figures written to", OUT)
