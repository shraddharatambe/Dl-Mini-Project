"""Plot loss + PSNR/SSIM curves from the CSV written by train.py.
    python scripts/plot_training.py --csv outputs/logs/train_log.csv --out outputs/figures/training_curves.png"""
import argparse

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd  # pip install pandas

ap = argparse.ArgumentParser()
ap.add_argument("--csv", default="outputs/logs/train_log.csv")
ap.add_argument("--out", default="outputs/figures/training_curves.png")
a = ap.parse_args()
df = pd.read_csv(a.csv)

fig, ax = plt.subplots(1, 2, figsize=(13, 4.5))
ax[0].plot(df.epoch, df.l1, label="Pixel L1")
ax[0].plot(df.epoch, df.vgg, label="VGG perceptual")
ax[0].plot(df.epoch, df.loss_d, "--", label="Relativistic D loss")
ax[0].set(title="Training losses vs epochs", xlabel="Epoch", ylabel="Loss"); ax[0].legend(); ax[0].grid(alpha=.3)
ax[1].plot(df.epoch, df.val_psnr, "g-", label="Val PSNR (dB)"); ax[1].set(xlabel="Epoch", ylabel="PSNR (dB)")
ax2 = ax[1].twinx(); ax2.plot(df.epoch, df.val_ssim, "b-.", label="Val SSIM"); ax2.set_ylabel("SSIM")
ax[1].set_title("Validation PSNR / SSIM"); ax[1].grid(alpha=.3)
plt.tight_layout(); plt.savefig(a.out, dpi=150); print("Saved", a.out)
