"""RRDB-Net generator (ESRGAN) - no Batch Normalization, residual scaling beta."""
import torch
import torch.nn as nn
import torch.nn.functional as F


class ResidualDenseBlock(nn.Module):
    """5-conv dense block; features of all previous layers are concatenated."""

    def __init__(self, nf: int = 64, gc: int = 32, beta: float = 0.2, bias: bool = True):
        super().__init__()
        self.beta = beta
        self.conv1 = nn.Conv2d(nf, gc, 3, 1, 1, bias=bias)
        self.conv2 = nn.Conv2d(nf + gc, gc, 3, 1, 1, bias=bias)
        self.conv3 = nn.Conv2d(nf + 2 * gc, gc, 3, 1, 1, bias=bias)
        self.conv4 = nn.Conv2d(nf + 3 * gc, gc, 3, 1, 1, bias=bias)
        self.conv5 = nn.Conv2d(nf + 4 * gc, nf, 3, 1, 1, bias=bias)
        self.lrelu = nn.LeakyReLU(0.2, inplace=True)
        self._init_weights()

    def _init_weights(self, scale: float = 0.1):
        # Small init (as in ESRGAN) for stable training of deep residual trunk
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight)
                m.weight.data *= scale
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        x2 = self.lrelu(self.conv2(torch.cat((x, x1), 1)))
        x3 = self.lrelu(self.conv3(torch.cat((x, x1, x2), 1)))
        x4 = self.lrelu(self.conv4(torch.cat((x, x1, x2, x3), 1)))
        x5 = self.conv5(torch.cat((x, x1, x2, x3, x4), 1))
        return x5 * self.beta + x


class RRDB(nn.Module):
    """Residual-in-Residual Dense Block: 3 dense blocks + outer residual."""

    def __init__(self, nf: int = 64, gc: int = 32, beta: float = 0.2):
        super().__init__()
        self.beta = beta
        self.rdb1 = ResidualDenseBlock(nf, gc, beta)
        self.rdb2 = ResidualDenseBlock(nf, gc, beta)
        self.rdb3 = ResidualDenseBlock(nf, gc, beta)

    def forward(self, x):
        out = self.rdb3(self.rdb2(self.rdb1(x)))
        return out * self.beta + x


class RRDBNet(nn.Module):
    """LR (B,3,H,W) in [0,1]  ->  SR (B,3,4H,4W).

    Shallow conv -> N x RRDB trunk (+ long skip) -> 2 x (conv + PixelShuffle(2)) -> output conv.
    """

    def __init__(self, in_nc=3, out_nc=3, nf=64, gc=32, num_rrdb=16, beta=0.2):
        super().__init__()
        self.conv_first = nn.Conv2d(in_nc, nf, 3, 1, 1)
        self.trunk = nn.Sequential(*[RRDB(nf, gc, beta) for _ in range(num_rrdb)])
        self.trunk_conv = nn.Conv2d(nf, nf, 3, 1, 1)
        # 4x upsampling = two sub-pixel (PixelShuffle x2) stages
        self.up1 = nn.Sequential(nn.Conv2d(nf, nf * 4, 3, 1, 1), nn.PixelShuffle(2), nn.LeakyReLU(0.2, True))
        self.up2 = nn.Sequential(nn.Conv2d(nf, nf * 4, 3, 1, 1), nn.PixelShuffle(2), nn.LeakyReLU(0.2, True))
        self.hr_conv = nn.Sequential(nn.Conv2d(nf, nf, 3, 1, 1), nn.LeakyReLU(0.2, True))
        self.conv_last = nn.Conv2d(nf, out_nc, 3, 1, 1)

    def forward(self, x):
        fea = self.conv_first(x)
        trunk = self.trunk_conv(self.trunk(fea))
        fea = fea + trunk                       # long residual skip connection
        fea = self.up2(self.up1(fea))
        return self.conv_last(self.hr_conv(fea))
