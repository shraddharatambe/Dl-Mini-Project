"""VGG-19 perceptual feature extractor (conv5_4 *before* activation)."""
import torch
import torch.nn as nn
from torchvision.models import vgg19, VGG19_Weights


class VGGFeatureExtractor(nn.Module):
    def __init__(self, pretrained: bool = True):
        super().__init__()
        weights = VGG19_Weights.IMAGENET1K_V1 if pretrained else None
        # features[:35] ends at conv5_4 (index 34), i.e. before its ReLU (index 35)
        self.features = vgg19(weights=weights).features[:35].eval()
        for p in self.features.parameters():
            p.requires_grad = False
        self.register_buffer("mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer("std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))

    def forward(self, x):                       # x in [0,1]
        return self.features((x - self.mean) / self.std)
