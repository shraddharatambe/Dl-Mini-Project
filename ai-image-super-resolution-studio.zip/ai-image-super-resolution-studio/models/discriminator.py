"""VGG-style discriminator with Spectral Normalization.

It outputs a raw logit C(x). The *relativistic average* formulation
D_Ra(x_r, x_f) = sigmoid(C(x_r) - E[C(x_f)]) is applied in the loss
(see utils/losses.py), exactly as in RaGAN.
"""
import torch.nn as nn
from torch.nn.utils import spectral_norm as sn


def _block(cin, cout, k, s):
    return [sn(nn.Conv2d(cin, cout, k, s, 1)), nn.LeakyReLU(0.2, True)]


class RelativisticDiscriminator(nn.Module):
    def __init__(self, in_nc: int = 3, base_nf: int = 64):
        super().__init__()
        nf = base_nf
        layers = []
        layers += _block(in_nc, nf, 3, 1)         # 1: 64
        layers += _block(nf, nf, 4, 2)            # 2: 64  (/2)
        layers += _block(nf, nf * 2, 3, 1)        # 3: 128
        layers += _block(nf * 2, nf * 2, 4, 2)    # 4: 128 (/4)
        layers += _block(nf * 2, nf * 4, 3, 1)    # 5: 256
        layers += _block(nf * 4, nf * 4, 4, 2)    # 6: 256 (/8)
        layers += _block(nf * 4, nf * 8, 4, 2)    # 7: 512 (/16)
        self.features = nn.Sequential(*layers)
        # Adaptive pooling makes the head independent of the input crop size
        self.pool = nn.AdaptiveAvgPool2d(4)
        self.classifier = nn.Sequential(
            nn.Linear(nf * 8 * 4 * 4, 100), nn.LeakyReLU(0.2, True), nn.Linear(100, 1)
        )

    def forward(self, x):
        f = self.pool(self.features(x))
        return self.classifier(f.flatten(1))
